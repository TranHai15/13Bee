import React from "react";

export default function ViewChat() {
  return (
    <div>
      <h1>View chat chi tiet</h1>
    </div>
  );
}
