// # Cấu hình xác thực bằng Google OAuth2 và JWT
